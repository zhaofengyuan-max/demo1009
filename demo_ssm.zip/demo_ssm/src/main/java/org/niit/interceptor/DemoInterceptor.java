package org.niit.interceptor;

public class DemoInterceptor {

}
